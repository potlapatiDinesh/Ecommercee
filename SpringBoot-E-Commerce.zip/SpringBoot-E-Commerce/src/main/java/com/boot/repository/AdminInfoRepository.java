package com.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.entity.AdminInfo;

public interface AdminInfoRepository extends JpaRepository<AdminInfo, Long>{

}
