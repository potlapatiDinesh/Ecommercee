package com.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.entity.Favourite;

public interface FavouriteRepository extends JpaRepository<Favourite, Long>{
	

	@Query(value="select*from favourite where user_email=:email",nativeQuery = true)
	public List<Favourite> getFavouriteByEmail(@Param("email") String email);
}
