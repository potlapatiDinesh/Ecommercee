package com.boot.service;

import java.util.List;

import com.boot.entity.Favourite;

public interface FavouriteService {

	//add to Favorite
	public Favourite addFavourite(Favourite favourite);
	
	//get All Favorite
	public List<Favourite> getAllFavoriteByEmail(String email);
	
	//getFavoriteById
	public Favourite getFavoriteById(long id);
	
	//delete Favorite
	public void deleteFavouriteById(long id);
}
