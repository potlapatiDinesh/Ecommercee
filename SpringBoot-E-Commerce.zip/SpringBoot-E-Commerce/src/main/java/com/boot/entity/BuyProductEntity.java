package com.boot.entity;

import javax.persistence.*;

@Entity
public class BuyProductEntity
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private String userEmail;
	
	@Column
	private long productId;
	
	@Column
	private String imgUrl;
	
	@Column
	private String productName;
	
	@Column
	private String price;
	
	@Column
	private String paymentMethod;
	
	@Column
	private long debitCardNumber;
	
	@Column
	private String cardWonerName;
	
	@Column
	private String cvv;
	
	@Column
	private int month;
	
	@Column
	private int year;

	@Column
	private String bankName;
	
	@Column
	private String bankBranch;
	
	@Column
	private String bankAccountHolderName;
	
	@Column
	private long accountNumber;
	
	@Column
	private String upi;
	
	@Column
	private String googlePayUserName;
	
	@Column
	private String date;
	
	

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public long getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(long debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public String getCardWonerName() {
		return cardWonerName;
	}

	public void setCardWonerName(String cardWonerName) {
		this.cardWonerName = cardWonerName;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getBankAccountHolderName() {
		return bankAccountHolderName;
	}

	public void setBankAccountHolderName(String bankAccountHolderName) {
		this.bankAccountHolderName = bankAccountHolderName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUpi() {
		return upi;
	}

	public void setUpi(String upi) {
		this.upi = upi;
	}

	public String getGooglePayUserName() {
		return googlePayUserName;
	}

	public void setGooglePayUserName(String googlePayUserName) {
		this.googlePayUserName = googlePayUserName;
	}
	
	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public BuyProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BuyProductEntity [id=" + id + ", userEmail=" + userEmail + ", productId=" + productId + ", imgUrl="
				+ imgUrl + ", productName=" + productName + ", price=" + price + ", paymentMethod=" + paymentMethod
				+ ", debitCardNumber=" + debitCardNumber + ", cardWonerName=" + cardWonerName + ", cvv=" + cvv
				+ ", month=" + month + ", year=" + year + ", bankName=" + bankName + ", bankBranch=" + bankBranch
				+ ", bankAccountHolderName=" + bankAccountHolderName + ", accountNumber=" + accountNumber + ", upi="
				+ upi + ", googlePayUserName=" + googlePayUserName + ", date=" + date + "]";
	}


	
	
	
	
}
