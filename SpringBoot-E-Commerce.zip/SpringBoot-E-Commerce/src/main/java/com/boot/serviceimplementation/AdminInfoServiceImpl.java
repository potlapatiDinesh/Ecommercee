package com.boot.serviceimplementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.AdminInfo;
import com.boot.repository.AdminInfoRepository;
import com.boot.service.AdminInfoService;

@Service
public class AdminInfoServiceImpl implements AdminInfoService {

	private AdminInfoRepository repository;
	
	public AdminInfoServiceImpl(AdminInfoRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public AdminInfo updateAdmin(AdminInfo admin) {
	
		return repository.save(admin);
	}

	@Override
	public AdminInfo getAdminInfoId(long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public List<AdminInfo> getAllAdmin() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
