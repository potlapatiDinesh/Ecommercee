package com.boot.serviceimplementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.ProductEntity;
import com.boot.exception.ResourceNotFoungException;
import com.boot.repository.ProductRepository;
import com.boot.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService 
{
	
	Long[] productId;
	
	private ProductRepository productRepository;
	
	public ProductServiceImpl(ProductRepository productRepository)
	{
		super();
		this.productRepository = productRepository;
	}

	@Override
	public ProductEntity addProduct(ProductEntity product) 
	{
		return productRepository.save(product);
	}

	@Override
	public List<ProductEntity> getAllProduct() 
	{	
		return productRepository.findAll();
	}

	@Override
	public ProductEntity updateProductById(long productId, ProductEntity product) 
	{	
		productRepository.findById(productId).orElseThrow(()->new ResourceNotFoungException("ProductSerialNo",productId));
		return productRepository.save(product);
	}

	@Override
	public String deleteProductById(long productId) 
	{
		productRepository.deleteById(productId);	
		
		return "Record Deleted SucessFully";
	}

	@Override
	public ProductEntity getProductById(long productId) 
	{	
		return productRepository.findById(productId).get();
	}

	@Override
	public List<ProductEntity> getAllProductByiId() 
	{
		List<ProductEntity> productEntityList=new ArrayList<ProductEntity>();
		for(int i=0;i<productId.length;i++)
		{
			productEntityList.add(productRepository.getProductsByProductId(productId[i]));
		}
		return productEntityList;
	}
	
	@Override
	public Long[] getAllProductId()
	{	
		
		return this.productId=productRepository.getAllProductId(); 
		//return null;
	}

	@Override
	public List<ProductEntity> getAllProductBySerch(String productName) {
		
		return productRepository.getAllProductBySerch(productName);
	}
	
	
	
}
